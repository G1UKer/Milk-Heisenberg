import React, { useState } from "react";
import { calculateAlchemyBonuses } from "../services/calculateAlchemyBonuses";
import itemData from "../data/item-data.json";

const equipmentOptions = [
  "Alchemist's Bottoms", "Alchemist's Top", "Enchanted Gloves"
];

const drinkOptions = [
  "Alchemy Tea", "Super Alchemy Tea", "Ultra Alchemy Tea",
  "Wisdom Tea", "Efficiency Tea", "Catalytic Tea"
];

const catalystOptions = [
  "Catalyst Of Coinification", "Catalyst Of Decomposition",
  "Catalyst Of Transmutation", "Prime Catalyst"
];

const necklaceOptions = [
  "Necklace of Efficiency", "Necklace of Wisdom",
  "Necklace of Speed", "Philosopher's Necklace"
];

const toolOptions = [
  "None", "Cheese Alembic", "Verdant Alembic", "Azure Alembic",
  "Burble Alembic", "Crimson Alembic", "Rainbow Alembic",
  "Holy Alembic", "Celestial Alembic"
];

const columnStyle = {
  flex: 1,
  padding: "0 1rem",
  minWidth: "250px"
};

export default function AlchemySettings() {
  const [alchemyLevel, setAlchemyLevel] = useState(1);
  const [labLevel, setLabLevel] = useState(0);
  const [communityXP, setCommunityXP] = useState(0);
  const [communityEfficiency, setCommunityEfficiency] = useState(0);
  const [houseXPBonus, setHouseXPBonus] = useState(0);
  const [tool, setTool] = useState("None");
  const [enhancementLevel, setEnhancementLevel] = useState(0);
  const [equipment, setEquipment] = useState([]);
  const [drinks, setDrinks] = useState([]);
  const [catalysts, setCatalysts] = useState([]);
  const [necklace, setNecklace] = useState("");

  const toggleSelection = (item, state, setState, single = false) => {
    if (single) {
      setState(item === state ? "" : item);
    } else {
      setState(state.includes(item)
        ? state.filter(i => i !== item)
        : [...state, item]);
    }
  };

  const toggleCatalyst = (selected) => {
    if (selected === "Prime Catalyst") {
      setCatalysts(catalysts.includes("Prime Catalyst") ? [] : ["Prime Catalyst"]);
    } else {
      setCatalysts(prev =>
        prev.includes(selected)
          ? prev.filter(c => c !== selected)
          : prev.filter(c => c !== "Prime Catalyst").concat(selected)
      );
    }
  };

  const bonuses = calculateAlchemyBonuses({
    alchemyLevel,
    labLevel,
    communityXPBuffLevel: communityXP,
    communityEfficiencyBuffLevel: communityEfficiency,
    houseXPBonus,
    tool,
    toolEnhancement: enhancementLevel,
    equipment,
    drinks,
    catalysts,
    necklace
  });

  return (
    <div style={{ display: "flex", flexWrap: "wrap", padding: "1rem" }}>
      {/* Column 1 */}
      <div style={columnStyle}>
        <h3>Core Settings</h3>

        <div><label>Alchemy Level:</label><input type="number" min="1" max="200" value={alchemyLevel} onChange={e => setAlchemyLevel(Number(e.target.value))} /></div>
        <div><label>Lab Level:</label><input type="number" min="0" max="8" value={labLevel} onChange={e => setLabLevel(Number(e.target.value))} /></div>
        <div><label>Community Buff - XP:</label><input type="number" min="0" max="20" value={communityXP} onChange={e => setCommunityXP(Number(e.target.value))} /></div>
        <div><label>Community Buff - Efficiency:</label><input type="number" min="0" max="20" value={communityEfficiency} onChange={e => setCommunityEfficiency(Number(e.target.value))} /></div>
        <div><label>House XP Bonus (%):</label><input type="number" min="0" value={houseXPBonus} onChange={e => setHouseXPBonus(Number(e.target.value))} /></div>
        <div><label>Tool:</label><select value={tool} onChange={e => setTool(e.target.value)}>{toolOptions.map(t => (<option key={t}>{t}</option>))}</select></div>
        <div><label>Enhancement Level:</label><input type="number" min="0" max="20" value={enhancementLevel} onChange={e => setEnhancementLevel(Number(e.target.value))} /></div>
      </div>

      {/* Column 2 */}
      <div style={columnStyle}>
        <h3>Equipment</h3>
        {equipmentOptions.map(item => (
          <label key={item}><input type="checkbox" checked={equipment.includes(item)} onChange={() => toggleSelection(item, equipment, setEquipment)} /> {item}</label>
        ))}

        <h3>Drinks</h3>
        {drinkOptions.map(drink => (
          <label key={drink}><input type="checkbox" checked={drinks.includes(drink)} onChange={() => toggleSelection(drink, drinks, setDrinks)} /> {drink}</label>
        ))}
      </div>

      {/* Column 3 */}
      <div style={columnStyle}>
        <h3>Catalysts</h3>
        {catalystOptions.map(cat => (
          <label key={cat}><input type="checkbox" checked={catalysts.includes(cat)} onChange={() => toggleCatalyst(cat)} /> {cat}</label>
        ))}

        <h3>Necklace</h3>
        {necklaceOptions.map(n => (
          <label key={n}><input type="checkbox" checked={necklace === n} onChange={() => toggleSelection(n, necklace, setNecklace, true)} /> {n}</label>
        ))}
      </div>

      {/* Column 4 */}
      <div style={{
        ...columnStyle,
        backgroundColor: "#e8fff0",
        border: "1px solid #b1e3c1",
        borderRadius: "6px",
        padding: "1rem",
        marginTop: "1rem"
      }}>
        <h3>Computed Bonuses</h3>
        <p><strong>XP Bonus:</strong> {bonuses.xpBonus.toFixed(2)}%</p>
        <p><strong>Efficiency Bonus:</strong> {bonuses.efficiency.toFixed(2)}%</p>
        <p><strong>Speed Bonus:</strong> {bonuses.speedBonus.toFixed(2)}%</p>
        <p><strong>Coinify Success:</strong> ×{bonuses.successMultipliers.Coinify.toFixed(2)}</p>
        <p><strong>Decompose Success:</strong> ×{bonuses.successMultipliers.Decompose.toFixed(2)}</p>
        <p><strong>Transmute Success:</strong> ×{bonuses.successMultipliers.Transmute.toFixed(2)}</p>
        <p><strong>Action Duration:</strong> {bonuses.effectiveDuration.toFixed(2)}s</p>
        <p><strong>Average Repeats:</strong> ×{bonuses.averageRepeats.toFixed(2)}</p>
        <p><strong>Coinify Profit/Action:</strong> {bonuses.profitPerAction} coins</p>
      </div>
    </div>
  );
}
